/* Settings page: persists to chrome.storage.sync, shared with popup + content. */
(function () {
  'use strict';

  var DEFAULTS = {
    enabled: true,
    position: 'top-right',
    rules: { hitSoft17: false, das: true, surrender: false }
  };

  var el = {
    enabled: document.getElementById('enabled'),
    hitSoft17: document.getElementById('hitSoft17'),
    das: document.getElementById('das'),
    surrender: document.getElementById('surrender'),
    posGrid: document.getElementById('posGrid'),
    reset: document.getElementById('reset'),
    saved: document.getElementById('saved')
  };
  var position = DEFAULTS.position;

  function flashSaved() {
    el.saved.classList.add('show');
    clearTimeout(flashSaved._t);
    flashSaved._t = setTimeout(function () { el.saved.classList.remove('show'); }, 1200);
  }

  function collect() {
    return {
      enabled: el.enabled.checked,
      position: position,
      rules: {
        hitSoft17: el.hitSoft17.checked,
        das: el.das.checked,
        surrender: el.surrender.checked
      }
    };
  }

  function save() {
    try { chrome.storage.sync.set(collect(), flashSaved); } catch (e) {}
  }

  function paintPosition() {
    Array.prototype.forEach.call(el.posGrid.children, function (b) {
      b.classList.toggle('active', b.dataset.pos === position);
    });
  }

  function apply(cfg) {
    el.enabled.checked = cfg.enabled !== false;
    el.hitSoft17.checked = !!cfg.rules.hitSoft17;
    el.das.checked = cfg.rules.das !== false;
    el.surrender.checked = cfg.rules.surrender === true;
    position = cfg.position || DEFAULTS.position;
    paintPosition();
  }

  function load() {
    try {
      chrome.storage.sync.get(['enabled', 'position', 'rules'], function (data) {
        apply({
          enabled: typeof data.enabled === 'boolean' ? data.enabled : DEFAULTS.enabled,
          position: data.position || DEFAULTS.position,
          rules: Object.assign({}, DEFAULTS.rules, data.rules || {})
        });
      });
    } catch (e) { apply(DEFAULTS); }
  }

  ['enabled', 'hitSoft17', 'das', 'surrender'].forEach(function (k) {
    el[k].addEventListener('change', save);
  });
  el.posGrid.addEventListener('click', function (e) {
    var b = e.target.closest('button[data-pos]');
    if (!b) return;
    position = b.dataset.pos;
    paintPosition();
    save();
  });
  el.reset.addEventListener('click', function () {
    apply(JSON.parse(JSON.stringify(DEFAULTS)));
    save();
  });

  load();
})();
